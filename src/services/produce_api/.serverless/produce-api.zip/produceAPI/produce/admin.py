from django.contrib import admin
from .models import Produce

admin.site.register(Produce)
