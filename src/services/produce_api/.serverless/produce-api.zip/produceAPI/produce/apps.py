from django.apps import AppConfig


class ProduceConfig(AppConfig):
    name = 'produce'
