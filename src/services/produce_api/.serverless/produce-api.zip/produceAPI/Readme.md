What Is This?
________________________________
This is a simple django rest application programming interface (API) intented to provide Farmrail's produce API. The goal of these end points is  to be simple, well-documented and to provide a base for developers to create applications off of.

How To Use This?
________________________________
Install the dependencies listed in the requirements.txt file
Run the command pip install -r requirements.txt
Run the command python manage.py runserver
open your browser at find the app running at http://127.0.0.1:8000/

Testing
_________________________________
to test the endpoints, run the command pythhon manage.py test